package ca.brocku.calculator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.ToggleButton;
//     M A I N      A C T I V I T Y
public class MainActivity extends AppCompatActivity {
    TextView numInput,numResult;
    Button correct,allClear,decimalPt,equal;
    Button division,multiplication,addition,subtraction;
    Button zero,one,two,three,four,five,six,seven,eight,nine;

    //Work variables

    Boolean lastNumeric = false;
    Boolean lastDot = false;
    Boolean enterable = true;

    int operands = 0;
    int ans = 0;
    //1 is basic model
    //2 is formula entry mode
    int option = 1;

    String z = "";
    String operator = "";
    String tempS;
    // --------------------------------------
    public void op_eval(String operator) {
        if (enterable) {
            if (lastNumeric) {
                operands += 1;
                lastNumeric = false;
                if (operands == 2 && option == 1) {
                    double ans = Calculate.evaluate(z);

                    int temp = (int)ans;
                    if(temp == ans){
                        tempS = Integer.toString(temp);
                    }
                    else {

                        tempS = Double.toString(ans);
                    }

                    z = tempS + operator;
                    numInput.setText(z);
                    numResult.setText("");
                    operands = 1;
                    lastNumeric = false;
                    lastDot = false;
                } else {
                    z += operator;
                    numInput.setText(z);
                    numResult.setText("");
                    lastNumeric = false;
                    lastDot = false;
                }
            } else if (z.length() > 0) {
                z = z.substring(0, z.length() - 1) + operator;
                numInput.setText(z);
                numResult.setText("");
                lastNumeric = false;
                lastDot = false;
            }
        }
    }

    @Override
    // ----------------------------------------------------------------------------
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //toggle button check if clicked
        ToggleButton toggle = (ToggleButton) findViewById(R.id.toggle1);
        toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton btnView, boolean isChecked) {
                //System.out.println("before option is" + option);
                if (isChecked) {
                    option = 1;}
                else
                    {option = 2;}
                //System.out.println("after option is" + option);

                numInput.setText("");
                numResult.setText("");
                z = "";
                enterable = true;
                lastDot = false;
                lastNumeric = false;
                operands = 0;
                operator = "";
                }
            }
            );


        numInput = findViewById(R.id.numInput);
        numResult = findViewById(R.id.numResult);

        correct = findViewById(R.id.correct);
        allClear = findViewById(R.id.allClear);
        decimalPt = findViewById(R.id.decimalPt);
        equal = findViewById(R.id.equal);

        division = findViewById(R.id.division);
        multiplication = findViewById(R.id.multiplication);
        addition = findViewById(R.id.addition);
        subtraction = findViewById(R.id.subtraction);

        zero = findViewById(R.id.zero);
        one = findViewById(R.id.one);
        two = findViewById(R.id.two);
        three = findViewById(R.id.three);
        four = findViewById(R.id.four);
        five = findViewById(R.id.five);
        six = findViewById(R.id.six);
        seven = findViewById(R.id.seven);
        eight = findViewById(R.id.eight);
        nine = findViewById(R.id.nine);

        // ===============================================================
        //on click functions

        correct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    if ( z.length() > 0 && enterable ) {
                        int len = z.length();
                        String deletedChar = z.substring(len-1,len);
                        if(deletedChar.equals(".")){
                            lastDot = false;
                        }
                        if("+-x÷".contains(deletedChar) && operands>0){
                            operands -= 1;
                        }
                        z = z.substring(0, z.length() - 1);
                        //System.out.println(z);
                        numInput.setText(z);
                        numResult.setText("");
                        len = z.length();
                        if(len > 0){
                            String z1 = z.substring(len-1);
                            if("0123456789.".contains(z1)){
                                lastNumeric = true;
                            }
                            else{
                                lastNumeric = false;
                                lastDot = false;
                            }
                        }
                        else{
                            z = "";
                            numInput.setText("0");
                            numResult.setText("");
                            lastNumeric = false;
                            lastDot = false;
                        }
                    }
            }

        });
        allClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (z.length() > 0 ) {
                        numInput.setText("0");
                        numResult.setText("");
                        z = "";
                        lastNumeric =false;
                        lastDot = false;
                        operands = 0;
                        enterable = true;
            }
        }});
        decimalPt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!lastDot){
                    z += decimalPt.getText().toString();
                    numInput.setText(z);
                    numResult.setText("");
                    lastNumeric = true;
                    lastDot = true;
                    enterable = true;
                }
            }
        });
        equal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(lastNumeric && enterable){

                    double ans = Calculate.evaluate(z);


                    int temp = (int)ans;
                    if(temp == ans){
                        tempS = Integer.toString(temp);
                    }
                    else {
                        tempS = Double.toString(ans);
                    }
                    String zz = z + "=";

                    numInput.setText(zz);
                    numResult.setText(tempS);
                    operands = 0;
                    lastNumeric = true;
                    if(tempS.contains(".")){
                        lastDot = true;
                    }
                    else{
                        lastDot = false;
                    }
                    z = tempS;
                    enterable = true;
                }
            }
        });

        //onclick computation functions
        addition.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                operator = addition.getText().toString();
                op_eval(operator);

        }});
        subtraction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                operator = subtraction.getText().toString();
                op_eval(operator);
            }
        });
        division.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                operator = division.getText().toString();
                op_eval(operator);
            }
        });
        multiplication.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                operator = multiplication.getText().toString();
                op_eval(operator);
            }
        });

        //onclick number buttons
        zero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(enterable){
                    z += zero.getText().toString();
                    numInput.setText(z);
                    numResult.setText("");
                    lastNumeric = true;
            }
        }});
        one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(enterable){
                    z += one.getText().toString();
                    numInput.setText(z);
                    numResult.setText("");
                    lastNumeric = true;
                }

            }
        });
        two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(enterable){
                    z += two.getText().toString();
                    numInput.setText(z);
                    numResult.setText("");
                    lastNumeric = true;
                }

            }
        });
        three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(enterable){
                    z += three.getText().toString();
                    numInput.setText(z);
                    numResult.setText("");
                    lastNumeric = true;
                }

            }
        });
        four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(enterable){
                    z += four.getText().toString();
                    numInput.setText(z);
                    numResult.setText("");
                    lastNumeric = true;
                }

            }
        });
        five.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(enterable){
                    z += five.getText().toString();
                    numInput.setText(z);
                    numResult.setText("");
                    lastNumeric = true;
                }

            }
        });
        six.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(enterable){
                    z += six.getText().toString();
                    numInput.setText(z);
                    numResult.setText("");
                    lastNumeric = true;
                }

            }
        });
        seven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(enterable){
                    z += seven.getText().toString();
                    numInput.setText(z);
                    numResult.setText("");
                    lastNumeric = true;
                }

            }
        });
        eight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(enterable){
                    z += eight.getText().toString();
                    numInput.setText(z);
                    numResult.setText("");
                    lastNumeric = true;
                }

            }
        });
        nine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(enterable){
                    z += nine.getText().toString();
                    numInput.setText(z);
                    numResult.setText("");
                    lastNumeric = true;
                }

            }
        });
    }
}