package ca.brocku.calculator;

/* =================================================================================================
This program evaluates an expression represented by a String. For simplicity, the only binary
operations allowed  are +, -, *, and /.

Arithmetic Expressions can be written in one of three forms:

    Infix Notation: Operators are written between the operands they operate on, e.g. 3 + 4 .
    Prefix Notation: Operators are written before the operands, e.g + 3 4
    Postfix Notation: Operators are written after operands.

Infix notation is how expressions are written and recognized by humans and, generally, input to
calculators. Since they are harder to evaluate, they generally have to be converted to one of the
two remaining forms.

A very well known algorithm for converting an infix notation to a postfix notation is the Shunting
Yard Algorithm by Edgar Dijkstra. This algorithm takes as input an Infix Expression and produces
a queue that has this expression converted to a postfix notation.

Code obtained from the Geeks for Geeks site (https://www.geeksforgeeks.org/expression-evaluation/)
was modified to accept input in specified format from MainActivity.java and to process double
variables rather than integer variables.

================================================================================================= */

import java.util.Stack;

public class Calculate {
    public static double evaluate(String s1) {
        // Take care of negative numbers
        if(s1.substring(0,1).equals("-")){
            s1 = "0" + s1;
        }
        String expression = "";
        // Convert division and operator signs
        int len1 = s1.length();
        for(int j=0; j<len1; j++){
            String ch1 = s1.substring(j,j+1);
            if(ch1.equals("÷")){
                expression = expression + "/";
            }
            else if (ch1.equals("x")){
                expression = expression + "*";
            }
            else {
                expression = expression + ch1;
            }
            //At this stage we have a valid expression
        }

        //==========Convert expression to separate tokens with a space=============
        // Convert expression to str2
        int len = expression.length();
        String str2 = "";
        Boolean last_char_digit = false;
        for (int j = 0; j < len; j++) {

            String c = expression.substring(j, j + 1);

            if ("0123456789.".contains(c) && last_char_digit) {
                str2 = str2 + c;
                last_char_digit = true;
            } else if ("0123456789.".contains(c) && !last_char_digit) {
                str2 = str2 + " " + c;
                last_char_digit = true;
            } else if (!("0123456789.".contains(c))) {
                str2 = str2 + " " + c;
                last_char_digit = false;
            }
        }

//*************************************************

        char[] tokens = str2.toCharArray();

        // Stack for numbers: 'values'
        Stack<Double> values = new Stack<Double>();
        String Digits = "0123456789.";

        // Stack for Operators: 'ops'
        Stack<Character> ops = new Stack<Character>();

        for (int i = 0; i < tokens.length; i++) {
            // Current token is a whitespace, skip it
            if (tokens[i] == ' ')
                continue;

            // Current token is a number, push it to stack for numbers

            if (Digits.contains(Character.toString(tokens[i]))) {
                StringBuffer sbuf = new StringBuffer();
                // There may be more than one digits in number
                while (i < tokens.length && Digits.contains(Character.toString(tokens[i])))
                    sbuf.append(tokens[i++]);
                values.push(Double.parseDouble(sbuf.toString()));
            }

            // Current token is an opening brace, push it to 'ops'
            else if (tokens[i] == '(')
                ops.push(tokens[i]);

                // Closing brace encountered, solve entire brace
            else if (tokens[i] == ')') {
                while (ops.peek() != '(')
                    values.push(applyOp(ops.pop(), values.pop(), values.pop()));
                ops.pop();
            }

            // Current token is an operator.
            else if (tokens[i] == '+' || tokens[i] == '-' ||
                    tokens[i] == '*' || tokens[i] == '/') {
                // While top of 'ops' has same or greater precedence to current
                // token, which is an operator. Apply operator on top of 'ops'
                // to top two elements in values stack
                while (!ops.empty() && hasPrecedence(tokens[i], ops.peek()))
                    values.push(applyOp(ops.pop(), values.pop(), values.pop()));

                // Push current token to 'ops'.
                ops.push(tokens[i]);
            }
        }

        // Entire expression has been parsed at this point, apply remaining
        // ops to remaining values
        while (!ops.empty())
            values.push(applyOp(ops.pop(), values.pop(), values.pop()));

        // Top of 'values' contains result, return it
        return values.pop();
    }

    // Returns true if 'op2' has higher or same precedence as 'op1',
    // otherwise returns false.
    public static boolean hasPrecedence(char op1, char op2) {
        if (op2 == '(' || op2 == ')')
            return false;
        if ((op1 == '*' || op1 == '/') && (op2 == '+' || op2 == '-'))
            return false;
        else
            return true;
    }

    // A utility method to apply an operator 'op' on operands 'a'
    // and 'b'. Return the result.
    public static double applyOp(char op, double b, double a) {

        switch (op) {
            case '+':
                return a + b;
            case '-':
                return a - b;
            case '*':
                return a * b;
            case '/':
                if (b == 0) {
                    // Division by zero
                    return 0;
                } else {
//                    throw new
//                            UnsupportedOperationException("Cannot divide by zero");
                    return a / b;
                }
        }
        return 0;
    }
}